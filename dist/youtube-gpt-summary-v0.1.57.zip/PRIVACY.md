# YouTube GPT Summary Privacy Policy and Disclaimer

Last updated: 2026-05-09 KST

This document describes how the YouTube GPT Summary Chrome extension handles data, what third-party services may receive user-directed content, and what limitations apply to summaries generated through ChatGPT or Gemini.

## 1. Service Overview

YouTube GPT Summary is a browser extension that helps users extract a YouTube video's available transcript and send it to ChatGPT or Gemini with a selected prompt for summarization or audit-style analysis.

YouTube GPT Summary is an independent tool. It is not affiliated with, sponsored by, endorsed by, or officially approved by YouTube, Google, OpenAI, ChatGPT, or Gemini. YouTube, Google, OpenAI, ChatGPT, Gemini, and related names or trademarks are the property of their respective owners.

## 2. Data Processed by the Extension

The extension may process the following data in the user's browser to provide its user-facing summary workflow:

- YouTube video title
- YouTube video URL
- YouTube video ID
- YouTube transcript or caption text
- User-entered custom prompt
- Prompt mode setting
- Output language setting
- ChatGPT model selection setting
- Gemini model selection setting
- Temporary Chat setting
- Auto-submit setting
- Aggressive transcript prefetch setting
- Temporary queue data used to send prepared prompts to ChatGPT or Gemini

The extension uses this data only to prepare and send a prompt to ChatGPT or Gemini when the user uses the summarization workflow.

## 3. Local Storage

The extension stores user settings in Chrome extension storage so the settings remain available between browser sessions.

Stored settings may include:

- `customPrompt`
- `promptMode`
- `outputLanguage`
- `chatgptModel`
- `geminiModel`
- `aggressiveTranscriptPrefetch`
- `useTemporaryChat`
- `autoSubmit`

If the custom prompt is empty or contains only whitespace, it may be stored internally as `null`.

## 4. Temporary In-Browser Data

The extension may temporarily keep transcript data in the current YouTube tab's content-script memory to speed up the user's later click on the summarize button. This cache is local to the current browser tab and is not a permanent video history.

The extension may also use `chrome.storage.session` for temporary prompt-transfer data. Queue or pending-prompt data may include the final prompt, source metadata, request ID, selected ChatGPT or Gemini model setting, and related temporary workflow state. This data is used to process ChatGPT or Gemini prompt-transfer jobs and is not intended as permanent storage.

The extension does not permanently store:

- Video-by-video summary history
- Transcript history
- ChatGPT or Gemini response content
- ChatGPT or Gemini conversation history
- User account information
- Payment information
- Advertising identifiers

## 5. Data Sharing and Third-Party Services

The developer does not operate a server for this extension.

The extension does not send user data to a developer-operated server. The extension does not sell user data. The extension does not share user data with advertising networks, data brokers, credit scoring services, or retargeting services.

When the user activates the summarize workflow, the generated prompt may include the YouTube video title, URL, transcript, selected prompt text, and selected output-language instruction. That prompt may be inserted into ChatGPT or Gemini and submitted to ChatGPT/OpenAI or Gemini/Google according to the user's settings and actions.

Data sent to ChatGPT or OpenAI may be subject to OpenAI's terms, privacy policy, data handling rules, account settings, and Temporary Chat behavior.

Data sent to Gemini or Google may be subject to Google's terms, privacy policy, data handling rules, account settings, and Gemini Temporary Chat behavior.

The extension does not send transcript or prompt data to Claude or any separate analysis server.

The extension's use of user data is limited to providing or improving the extension's single user-facing purpose: preparing and sending a YouTube transcript-based prompt to ChatGPT or Gemini at the user's request. The extension does not use user data for advertising, creditworthiness, data brokerage, resale, or unrelated purposes.

## 6. Temporary Chat and Auto-Submit

The extension attempts to use ChatGPT Temporary Chat when the user has enabled the Temporary Chat setting.

Temporary Chat behavior, availability, URL behavior, user interface structure, data retention policy, and service operation are controlled by OpenAI and may change. The developer does not guarantee that Temporary Chat will always be available, will always be detected, or will always process data in a particular way.

For Gemini, the extension attempts to use Gemini Temporary Chat before inserting or submitting the prompt. Gemini Temporary Chat behavior, availability, user interface structure, data retention policy, and service operation are controlled by Google and may change. The developer does not guarantee that Gemini Temporary Chat will always be available, will always be detected, or will always process data in a particular way.

If the `autoSubmit` setting is enabled, clicking a summarize button may cause the generated prompt to be automatically inserted into the ChatGPT or Gemini composer and automatically submitted. If Gemini Temporary Chat cannot be confirmed, the extension should withhold Gemini auto-submit and leave the prompt in the composer when possible.

## 7. Clipboard Use

The extension may copy the generated final prompt to the clipboard as a fallback. This is intended to help the user paste the prompt manually if automatic ChatGPT injection fails or if browser focus restrictions prevent direct insertion.

## 8. Permissions and Host Access

The extension requests only the permissions needed for its stated workflow.

### `storage`

Used to store user settings and temporary queue state.

### `clipboardWrite`

Used to copy the generated prompt to the clipboard as a fallback.

### `https://www.youtube.com/*`

Used to insert the summarize button on YouTube watch pages and extract the available transcript.

### `https://chatgpt.com/*` and `https://chat.openai.com/*`

Used to insert the generated prompt into ChatGPT and, if enabled, submit it.

### `https://gemini.google.com/*`

Used to insert the generated prompt into Gemini Temporary Chat and, if enabled and Temporary Chat is confirmed, submit it.

## 9. Disclaimer

YouTube GPT Summary is not affiliated with, sponsored by, endorsed by, or officially approved by YouTube, Google, OpenAI, ChatGPT, or Gemini.

This extension helps users send YouTube transcript text to ChatGPT or Gemini for summarization or audit-style analysis. AI-generated summaries may be inaccurate, incomplete, outdated, or misleading. Users should verify important information directly from the original video, official materials, or other reliable sources.

This extension does not provide legal, medical, financial, investment, tax, accounting, or other professional advice. Generated summaries or analyses should not be used as a substitute for professional judgment, professional review, or professional advice.

This extension may be used for personal, educational, research, work, or business workflows. This permission applies only to use of the extension itself. It does not grant ownership, license, redistribution rights, commercial-use rights, or any other rights to YouTube videos, transcripts, captions, thumbnails, channel content, comments, brand elements, or other third-party content.

Users are solely responsible for ensuring that their use of transcripts, prompts, AI-generated summaries, and resulting materials complies with applicable laws, copyright rules, platform terms, third-party rights, and their organization's policies.

The developer does not guarantee that any transcript, summary, AI-generated output, or resulting material is legally safe for publication, redistribution, monetization, workplace use, or commercial use.

The extension does not operate its own AI model and does not guarantee the availability, accuracy, behavior, speed, output quality, policy stability, or uninterrupted operation of ChatGPT, OpenAI, Gemini, Google, YouTube, or any other third-party service.

## 10. Chrome Web Store Publication Notes

Before publishing, the Chrome Web Store listing, privacy disclosures, permission justifications, screenshots, and store description should remain consistent with this document.

The store description should clearly state that the extension sends YouTube transcript-based prompts to ChatGPT or Gemini when the user uses the corresponding summarize feature.

The permission justification should accurately explain YouTube page access, ChatGPT page access, Gemini page access, `storage`, and `clipboardWrite`.

The extension name, icon, screenshots, and description should not imply official affiliation, endorsement, sponsorship, or approval by YouTube, Google, OpenAI, ChatGPT, or Gemini.

## 11. References

- Chrome Web Store Privacy Policies: https://developer.chrome.com/docs/webstore/program-policies/privacy
- Chrome Web Store Program Policies: https://developer.chrome.com/docs/webstore/program-policies/policies
- Chrome Web Store User Data FAQ: https://developer.chrome.com/docs/webstore/program-policies/user-data-faq
- YouTube Terms of Service: https://www.youtube.com/static?template=terms
- OpenAI Temporary Chat FAQ: https://help.openai.com/en/articles/8914046-temporary-chat-faq
- OpenAI Brand Guidelines: https://openai.com/brand/
- Gemini Apps Help: https://support.google.com/gemini/answer/13275745
