globalThis.YGS = globalThis.YGS || {};

(() => {
  if (globalThis.YGS.__geminiContentScriptStarted) {
    return;
  }
  globalThis.YGS.__geminiContentScriptStarted = true;

  const INPUT_WAIT_MS = 20000;
  const POLL_MS = 300;

  const inputAdapters = [
    {
      name: "textarea",
      canHandle(element) {
        return element instanceof HTMLTextAreaElement || element instanceof HTMLInputElement;
      },
      inject(element, text) {
        element.focus();

        const prototype = element instanceof HTMLTextAreaElement
          ? HTMLTextAreaElement.prototype
          : HTMLInputElement.prototype;
        const descriptor = Object.getOwnPropertyDescriptor(prototype, "value");

        if (descriptor?.set) {
          descriptor.set.call(element, text);
        } else {
          element.value = text;
        }

        dispatchInputEvents(element, text);
      },
      read(element) {
        return element.value || "";
      }
    },
    {
      name: "contenteditable",
      canHandle(element) {
        return element instanceof HTMLElement && element.isContentEditable;
      },
      inject(element, text) {
        insertTextIntoContentEditable(element, text);
        dispatchInputEvents(element, text);
      },
      read(element) {
        return element.innerText || element.textContent || "";
      }
    }
  ];

  async function main() {
    await waitForDocumentReady();
    await delay(500);

    const requestId = parseRequestIdFromLocation();
    if (!requestId) {
      return;
    }

    const pending = await getPendingPrompt(requestId);
    if (!pending) {
      globalThis.YGS.log("No pending Gemini prompt found for request", requestId);
      return;
    }

    const temporaryConfirmed = await confirmGeminiTemporaryChatIfPossible();
    if (!temporaryConfirmed) {
      globalThis.YGS.warn("Gemini Temporary Chat not confirmed; prompt injection withheld");
      return;
    }

    const input = await waitForComposerInput(INPUT_WAIT_MS);
    if (!input) {
      globalThis.YGS.warn("Gemini composer input not found; pending prompt left available for manual paste");
      return;
    }

    await selectGeminiModelIfRequested(pending.geminiModel, input);

    const currentInput = findComposerInput() || input;
    const injected = injectPrompt(currentInput, pending.prompt);
    if (!injected) {
      globalThis.YGS.warn("Gemini prompt injection failed; pending prompt left available for manual paste");
      return;
    }

    await clearPendingPrompt(requestId);
    removeRequestIdHash();
    globalThis.YGS.log("Prompt injected into Gemini composer");

    if (pending.autoSubmit !== true) {
      globalThis.YGS.log("autoSubmit is false; Gemini prompt left in composer");
      return;
    }

    const submitted = await submitPrompt(currentInput);
    if (submitted) {
      globalThis.YGS.log("Gemini prompt submitted");
    } else {
      globalThis.YGS.warn("Gemini auto-submit failed; prompt should remain in composer");
    }
  }

  function parseRequestIdFromLocation() {
    const hash = location.hash.replace(/^#/, "");
    const params = new URLSearchParams(hash);
    return params.get("ygsRequestId") || "";
  }

  async function confirmGeminiTemporaryChatIfPossible() {
    const initialReason = getGeminiTemporaryChatActiveReason();
    if (initialReason) {
      globalThis.YGS.log("Gemini Temporary Chat confirmed", initialReason);
      return true;
    }

    const button = await waitForGeminiTemporaryChatButton(9000);
    if (button) {
      const confirmedByClick = await clickGeminiTemporaryChatWithRetry(button);
      if (confirmedByClick) {
        return true;
      }

      globalThis.YGS.warn("Gemini Temporary Chat confirmation diagnostics", getGeminiTemporaryChatDiagnostics());
      return false;
    }

    const finalReason = await waitForGeminiTemporaryChatActive(3000);
    if (finalReason) {
      globalThis.YGS.log("Gemini Temporary Chat confirmed after click", finalReason);
      return true;
    }

    globalThis.YGS.warn("Gemini Temporary Chat confirmation diagnostics", getGeminiTemporaryChatDiagnostics());
    return false;
  }

  async function clickGeminiTemporaryChatWithRetry(initialButton) {
    for (let attempt = 1; attempt <= 2; attempt += 1) {
      const activeReason = getGeminiTemporaryChatActiveReason();
      if (activeReason) {
        return true;
      }

      const button = attempt === 1
        ? initialButton
        : await waitForGeminiTemporaryChatButton(3000);

      if (!button) {
        return false;
      }

      try {
        globalThis.YGS.log("Clicking Gemini Temporary Chat button", getElementLabel(button));
        clickGeminiTemporaryChatControl(button);
        await delay(attempt === 1 ? 250 : 500);
      } catch (error) {
        globalThis.YGS.warn("Gemini Temporary Chat button click failed", error);
      }

      const confirmedReason = await waitForGeminiTemporaryChatActive(attempt === 1 ? 2500 : 4500);
      if (confirmedReason) {
        globalThis.YGS.log("Gemini Temporary Chat confirmed after click", confirmedReason);
        return true;
      }
    }

    return false;
  }

  function clickGeminiTemporaryChatControl(container) {
    const clickTarget = findExactGeminiTemporaryChatButton()
      || findBestClickableTemporaryChatTarget(container)
      || container;
    if (clickTarget !== container) {
      globalThis.YGS.log("Clicking Gemini Temporary Chat inner control", getElementLabel(clickTarget));
    }

    clickElementLikeUser(clickTarget);

    if (clickTarget === container) {
      clickElementAt(container, 0.25, 0.5);
      clickElementAt(container, 0.75, 0.5);
    }
  }

  function findBestClickableTemporaryChatTarget(container) {
    const candidates = Array.from(container.querySelectorAll("button, [role='button'], [role='switch'], input[type='checkbox'], mat-slide-toggle, mat-slide-toggle *"))
      .filter((element) => element instanceof HTMLElement)
      .filter(isVisible)
      .filter((element) => !isDisabled(element))
      .map((element) => ({
        element,
        score: getTemporaryChatInnerControlScore(element)
      }))
      .filter((entry) => entry.score > 0)
      .sort((left, right) => right.score - left.score);

    return candidates[0]?.element || null;
  }

  function getTemporaryChatInnerControlScore(element) {
    const label = normalizeForComparison(getElementLabel(element));
    let score = 1;

    if (element.getAttribute("role") === "switch") {
      score += 10;
    }

    if (element instanceof HTMLInputElement && element.type === "checkbox") {
      score += 9;
    }

    if (label.includes("temporary") || label.includes("임시")) {
      score += 6;
    }

    if (label.includes("chat") || label.includes("채팅") || label.includes("대화")) {
      score += 4;
    }

    const rect = element.getBoundingClientRect();
    if (rect.width <= 96 && rect.height <= 64) {
      score += 3;
    }

    return score;
  }

  async function waitForGeminiTemporaryChatActive(timeoutMs) {
    const startedAt = Date.now();

    while (Date.now() - startedAt < timeoutMs) {
      const reason = getGeminiTemporaryChatActiveReason();
      if (reason) {
        return reason;
      }

      await delay(POLL_MS);
    }

    return "";
  }

  async function waitForGeminiTemporaryChatButton(timeoutMs) {
    const startedAt = Date.now();

    while (Date.now() - startedAt < timeoutMs) {
      const button = findGeminiTemporaryChatButton();
      if (button) {
        return button;
      }

      await delay(POLL_MS);
    }

    return null;
  }

  function findGeminiTemporaryChatButton() {
    const exactButton = findExactGeminiTemporaryChatButton();
    if (exactButton) {
      return exactButton;
    }

    const candidates = Array.from(document.querySelectorAll("button, [role='button'], a[role='button'], [aria-label], [title]"))
      .filter((element) => element instanceof HTMLElement)
      .filter(isVisible)
      .filter((element) => !isDisabled(element))
      .map((element) => ({
        element,
        score: getGeminiTemporaryChatButtonScore(element)
      }))
      .filter((entry) => entry.score > 0)
      .sort((left, right) => right.score - left.score);

    return candidates[0]?.element || null;
  }

  function findExactGeminiTemporaryChatButton() {
    const selectors = [
      "button[data-test-id='temp-chat-button']",
      "[data-test-id='temp-chat-button']",
      "[data-test-id='temp-chat-button-container'] button",
      "temp-chat-button button",
      "button[aria-label='임시 채팅']",
      "button[aria-label='Temporary Chat']",
      "button[mattooltip='임시 채팅']",
      "button[mattooltip='Temporary Chat']"
    ];

    for (const selector of selectors) {
      try {
        const element = document.querySelector(selector);
        if (element instanceof HTMLElement && isVisible(element) && !isDisabled(element)) {
          return element;
        }
      } catch (_) {
        // Ignore selector failures.
      }
    }

    return null;
  }

  function getGeminiTemporaryChatButtonScore(element) {
    const label = normalizeForComparison(getElementLabel(element));
    let score = 0;

    if (label.includes("temporary chat") || label.includes("임시 채팅")) {
      score += 10;
    }

    if (label.includes("temporary") && label.includes("chat")) {
      score += 8;
    }

    if (label.includes("임시") && (label.includes("채팅") || label.includes("대화"))) {
      score += 8;
    }

    if (label.includes("new chat") || label.includes("새 채팅")) {
      score += 1;
    }

    const rect = element.getBoundingClientRect();
    if (rect.top < globalThis.innerHeight * 0.5) {
      score += 1;
    }

    return score;
  }

  function getGeminiTemporaryChatActiveReason() {
    const bodyText = normalizeForComparison(document.body?.innerText || "");
    const activeMarkers = [
      "ask in a temporary chat",
      "temporary chats don't appear",
      "temporary chats don’t appear",
      "won't appear in recent chats",
      "won’t appear in recent chats",
      "aren't used to train",
      "aren’t used to train",
      "gemini apps activity",
      "temporary chat is not shown",
      "temporary chat won't appear",
      "temporary chat won’t appear",
      "ask in temporary chat",
      "임시 채팅으로 질문",
      "임시 채팅에서 질문",
      "임시 채팅에서 질문해 보세요",
      "임시 채팅은 최근 채팅",
      "gemini 앱 활동에 표시되지",
      "표시되지 않으며",
      "사용되지 않습니다",
      "72시간 동안 저장",
      "최근 채팅에 표시되지",
      "학습에 사용되지"
    ];

    if (activeMarkers.some((marker) => bodyText.includes(marker))) {
      return "temporary-chat page copy";
    }

    const input = findComposerInput();
    const inputLabel = normalizeForComparison(input ? getElementLabel(input) : "");
    if (inputLabel.includes("temporary chat") || inputLabel.includes("임시 채팅")) {
      return "temporary-chat input label";
    }

    const composerText = normalizeForComparison(input ? getNearbyText(input) : "");
    if (
      composerText.includes("temporary chat")
      || composerText.includes("임시 채팅")
      || composerText.includes("임시채팅")
    ) {
      return "temporary-chat composer copy";
    }

    return "";
  }

  function getGeminiTemporaryChatDiagnostics() {
    const buttons = [
      ...Array.from(document.querySelectorAll("[data-test-id='temp-chat-button'], [data-test-id='temp-chat-button-container'], temp-chat-button button")),
      ...Array.from(document.querySelectorAll("button[aria-label], button[mattooltip]"))
        .filter((element) => {
          const label = normalizeForComparison(getElementLabel(element));
          return label.includes("임시") || label.includes("temporary");
        })
    ]
      .filter((element) => element instanceof HTMLElement)
      .filter(isVisible)
      .map((element) => ({
        label: normalizeForComparison(getElementLabel(element)).slice(0, 120),
        ariaPressed: element.getAttribute("aria-pressed") || "",
        ariaChecked: element.getAttribute("aria-checked") || "",
        dataState: element.getAttribute("data-state") || "",
        testId: element.getAttribute("data-test-id") || ""
      }))
      .slice(0, 8);

    const bodyText = normalizeForComparison(document.body?.innerText || "");
    return {
      url: location.href,
      temporaryButtons: buttons,
      bodySnippet: bodyText.slice(0, 300)
    };
  }

  async function selectGeminiModelIfRequested(value, input) {
    const model = getRequestedGeminiModel(value);
    if (!model || model.value === "none") {
      return true;
    }

    globalThis.YGS.log("Gemini model selection requested", model.label);

    const selector = await waitForGeminiModelSelector(input, 6000);
    if (!selector) {
      globalThis.YGS.warn("Gemini model selector not found; continuing with current model", model.label);
      return false;
    }

    const selectorLabel = getElementLabel(selector);
    globalThis.YGS.log("Gemini model selector found", selectorLabel);

    if (isGeminiModelLabelMatch(selectorLabel, model.selectedMatchers)) {
      globalThis.YGS.log("Gemini model already selected", model.label);
      return true;
    }

    try {
      clickElementLikeUser(selector);
      await delay(500);
    } catch (error) {
      globalThis.YGS.warn("Gemini model selector click failed; continuing with current model", error);
      return false;
    }

    const option = await waitForGeminiModelOption(model, selector, 5000);
    if (!option) {
      globalThis.YGS.warn("Gemini model option not found; continuing with current model", {
        requestedModel: model.label,
        menuCandidates: getVisibleGeminiModelMenuCandidates(selector)
      });
      return false;
    }

    globalThis.YGS.log("Gemini model option found", getElementLabel(option));

    try {
      clickElementLikeUser(option);
      await delay(700);
    } catch (error) {
      globalThis.YGS.warn("Gemini model option click failed; continuing with current model", error);
      return false;
    }

    const nextSelector = findGeminiModelSelector(input) || selector;
    const nextLabel = getElementLabel(nextSelector);
    if (isGeminiModelLabelMatch(nextLabel, model.selectedMatchers)) {
      globalThis.YGS.log("Gemini model selected", model.label);
      return true;
    }

    globalThis.YGS.log("Gemini model selection attempted", model.label);
    return true;
  }

  function getRequestedGeminiModel(value) {
    const normalized = String(value || "").trim().toLowerCase();
    return globalThis.YGS.GEMINI_MODELS.find((model) => model.value === normalized)
      || globalThis.YGS.GEMINI_MODELS.find((model) => model.value === "none");
  }

  async function waitForGeminiModelSelector(input, timeoutMs) {
    const startedAt = Date.now();

    while (Date.now() - startedAt < timeoutMs) {
      const selector = findGeminiModelSelector(input);
      if (selector) {
        return selector;
      }

      await delay(POLL_MS);
    }

    return null;
  }

  function findGeminiModelSelector(input) {
    const candidates = Array.from(document.querySelectorAll("button, [role='button']"))
      .filter((element) => element instanceof HTMLElement)
      .filter(isVisible)
      .filter((element) => !isDisabled(element))
      .map((element) => ({
        element,
        score: getGeminiModelSelectorScore(element, input)
      }))
      .filter((entry) => entry.score > 0)
      .sort((left, right) => right.score - left.score);

    return candidates[0]?.element || null;
  }

  function getGeminiModelSelectorScore(element, input) {
    const label = normalizeForComparison(getElementLabel(element));
    let score = 0;

    if (isAnyGeminiModelLabel(label)) {
      score += 8;
    }

    if (label.includes("model") || label.includes("모델")) {
      score += 3;
    }

    if (input && areElementsNear(element, input)) {
      score += 8;
      const elementRect = element.getBoundingClientRect();
      const inputRect = input.getBoundingClientRect();
      const elementCenterX = (elementRect.left + elementRect.right) / 2;
      if (elementCenterX > inputRect.left + inputRect.width * 0.55) {
        score += 4;
      }
    }

    const rect = element.getBoundingClientRect();
    if (rect.bottom > globalThis.innerHeight * 0.4) {
      score += 2;
    }

    if (label.includes("profile") || label.includes("account") || label.includes("프로필") || label.includes("계정")) {
      score -= 12;
    }

    return score;
  }

  async function waitForGeminiModelOption(model, selector, timeoutMs) {
    const startedAt = Date.now();

    while (Date.now() - startedAt < timeoutMs) {
      const option = findGeminiModelOption(model, selector);
      if (option) {
        return option;
      }

      await delay(POLL_MS);
    }

    return null;
  }

  function findGeminiModelOption(model, selector) {
    const candidates = Array.from(document.querySelectorAll("button, [role='button'], [role='option'], [role='menuitem'], li, div"))
      .filter((element) => element instanceof HTMLElement)
      .filter(isVisible)
      .filter((element) => !isDisabled(element))
      .filter((element) => element !== selector)
      .map((element) => ({
        element,
        score: getGeminiModelOptionScore(element, model, selector)
      }))
      .filter((entry) => entry.score > 0)
      .sort((left, right) => right.score - left.score);

    return candidates[0]?.element || null;
  }

  function getGeminiModelOptionScore(element, model, selector) {
    const label = normalizeForComparison(getElementLabel(element));
    let score = 0;

    if (isGeminiModelLabelMatch(label, model.matchers)) {
      score += 10;
    }

    const matchedModelCount = getMatchedGeminiModelCount(label);
    if (matchedModelCount > 1) {
      score -= matchedModelCount * 2;
    }

    if (label.includes("gemini 3")) {
      score -= 4;
    }

    if (selector && areElementsNear(element, selector)) {
      score += 4;
    }

    const rect = element.getBoundingClientRect();
    if (rect.width > 80 && rect.height > 24) {
      score += 1;
    }

    if (label.includes("profile") || label.includes("account") || label.includes("프로필") || label.includes("계정")) {
      score -= 12;
    }

    return score;
  }

  function getVisibleGeminiModelMenuCandidates(selector) {
    return Array.from(document.querySelectorAll("button, [role='button'], [role='option'], [role='menuitem'], li, div"))
      .filter((element) => element instanceof HTMLElement)
      .filter(isVisible)
      .map((element) => ({
        label: normalizeForComparison(getElementLabel(element)).slice(0, 120),
        nearSelector: selector ? areElementsNear(element, selector) : false
      }))
      .filter((candidate) => candidate.label)
      .slice(0, 20);
  }

  function isAnyGeminiModelLabel(label) {
    return globalThis.YGS.GEMINI_MODELS
      .filter((model) => model.value !== "none")
      .some((model) => isGeminiModelLabelMatch(label, model.selectedMatchers));
  }

  function getMatchedGeminiModelCount(label) {
    return globalThis.YGS.GEMINI_MODELS
      .filter((model) => model.value !== "none")
      .filter((model) => isGeminiModelLabelMatch(label, model.matchers))
      .length;
  }

  function isGeminiModelLabelMatch(value, matchers) {
    const label = normalizeForComparison(value);
    return Array.isArray(matchers)
      && matchers.some((matcher) => label.includes(normalizeForComparison(matcher)));
  }

  function removeRequestIdHash() {
    try {
      if (!location.hash.includes("ygsRequestId=")) {
        return;
      }

      const url = new URL(location.href);
      url.hash = "";
      history.replaceState(history.state, document.title, url.toString());
    } catch (error) {
      globalThis.YGS.warn("Failed to remove Gemini request id hash", error);
    }
  }

  async function getPendingPrompt(requestId) {
    try {
      const response = await chrome.runtime.sendMessage({
        type: globalThis.YGS.MESSAGE_TYPES.GET_PENDING_PROMPT,
        requestId
      });

      return response?.payload || null;
    } catch (error) {
      globalThis.YGS.warn("Failed to get pending Gemini prompt", error);
      return null;
    }
  }

  async function clearPendingPrompt(requestId) {
    try {
      await chrome.runtime.sendMessage({
        type: globalThis.YGS.MESSAGE_TYPES.CLEAR_PENDING_PROMPT,
        requestId
      });
    } catch (error) {
      globalThis.YGS.warn("Failed to clear pending Gemini prompt", error);
    }
  }

  async function waitForDocumentReady() {
    if (document.readyState === "complete" || document.readyState === "interactive") {
      return;
    }

    await new Promise((resolve) => {
      document.addEventListener("DOMContentLoaded", resolve, { once: true });
    });
  }

  async function waitForComposerInput(timeoutMs) {
    const startedAt = Date.now();

    while (Date.now() - startedAt < timeoutMs) {
      const input = findComposerInput();
      if (input) {
        return input;
      }

      await delay(POLL_MS);
    }

    return null;
  }

  function findComposerInput() {
    const selectors = [
      "rich-textarea [contenteditable='true']",
      "div.ql-editor[contenteditable='true']",
      "div.ProseMirror[contenteditable='true']",
      "[contenteditable='true'][role='textbox']",
      "[role='textbox'][contenteditable='true']",
      "[contenteditable='true']",
      "textarea",
      "input[type='text']"
    ];

    const candidates = [];

    for (const selector of selectors) {
      try {
        for (const element of document.querySelectorAll(selector)) {
          if (element instanceof HTMLElement && isUsableInputElement(element)) {
            candidates.push(element);
          }
        }
      } catch (_) {
        // Ignore selector failures.
      }
    }

    return uniqueElements(candidates)
      .map((element) => ({
        element,
        score: getInputScore(element)
      }))
      .filter((entry) => entry.score > 0)
      .sort((left, right) => right.score - left.score)[0]?.element || null;
  }

  function getInputScore(element) {
    const label = normalizeForComparison([
      element.getAttribute("aria-label") || "",
      element.getAttribute("placeholder") || "",
      element.getAttribute("data-placeholder") || "",
      element.textContent || ""
    ].join(" "));

    let score = 1;
    if (label.includes("prompt") || label.includes("message") || label.includes("질문") || label.includes("메시지")) {
      score += 5;
    }
    if (element.closest("rich-textarea, prompt-input, bard-prompt-input, .input-area, form")) {
      score += 4;
    }

    const rect = element.getBoundingClientRect();
    if (rect.bottom > globalThis.innerHeight * 0.45) {
      score += 2;
    }

    return score;
  }

  function isUsableInputElement(element) {
    if (!isVisible(element)) {
      return false;
    }

    if (element instanceof HTMLTextAreaElement || element instanceof HTMLInputElement) {
      return !element.disabled && !element.readOnly;
    }

    return element.isContentEditable;
  }

  function injectPrompt(element, prompt) {
    const adapter = inputAdapters.find((candidate) => candidate.canHandle(element));
    if (!adapter) {
      globalThis.YGS.warn("No input adapter matched Gemini composer input");
      return false;
    }

    try {
      adapter.inject(element, prompt);

      const actualText = normalizeForComparison(adapter.read(element));
      const expectedPrefix = normalizeForComparison(prompt).slice(0, 80);

      if (expectedPrefix && !actualText.includes(expectedPrefix)) {
        globalThis.YGS.warn("Gemini composer did not visibly contain expected prompt prefix", adapter.name);
      }

      return true;
    } catch (error) {
      globalThis.YGS.warn(`Gemini prompt injection failed in ${adapter.name} adapter`, error);
      return false;
    }
  }

  function insertTextIntoContentEditable(element, text) {
    element.focus();

    const selection = globalThis.getSelection();
    const range = document.createRange();
    range.selectNodeContents(element);

    selection.removeAllRanges();
    selection.addRange(range);

    const inserted = document.execCommand("insertText", false, text);
    if (!inserted || normalizeForComparison(element.innerText || element.textContent || "").length === 0) {
      element.textContent = text;
    }
  }

  function dispatchInputEvents(element, text) {
    try {
      element.dispatchEvent(new InputEvent("beforeinput", {
        bubbles: true,
        cancelable: true,
        inputType: "insertText",
        data: text
      }));
    } catch (_) {
      // Some pages may reject synthetic beforeinput details.
    }

    try {
      element.dispatchEvent(new InputEvent("input", {
        bubbles: true,
        inputType: "insertText",
        data: text
      }));
    } catch (_) {
      element.dispatchEvent(new Event("input", { bubbles: true }));
    }

    element.dispatchEvent(new Event("change", { bubbles: true }));
  }

  async function submitPrompt(input) {
    const button = await waitForSubmitButton(input, 6000);
    if (!button) {
      return false;
    }

    try {
      clickElementLikeUser(button);
      return true;
    } catch (error) {
      globalThis.YGS.warn("Gemini submit button click failed", error);
      return false;
    }
  }

  async function waitForSubmitButton(input, timeoutMs) {
    const startedAt = Date.now();

    while (Date.now() - startedAt < timeoutMs) {
      const button = findSubmitButton(input);
      if (button) {
        return button;
      }

      await delay(POLL_MS);
    }

    return null;
  }

  function findSubmitButton(input) {
    const candidates = Array.from(document.querySelectorAll("button, [role='button']"))
      .filter((element) => element instanceof HTMLElement)
      .filter(isVisible)
      .filter((element) => !isDisabled(element))
      .map((element) => ({
        element,
        score: getSubmitButtonScore(element, input)
      }))
      .filter((entry) => entry.score > 0)
      .sort((left, right) => right.score - left.score);

    return candidates[0]?.element || null;
  }

  function getSubmitButtonScore(element, input) {
    const label = normalizeForComparison(getElementLabel(element));
    let score = 0;

    if (
      label.includes("send")
      || label.includes("submit")
      || label.includes("전송")
      || label.includes("보내기")
      || label.includes("제출")
    ) {
      score += 8;
    }

    if (label.includes("voice") || label.includes("microphone") || label.includes("mic") || label.includes("upload")) {
      score -= 8;
    }

    if (element.querySelector("mat-icon, svg")) {
      score += 1;
    }

    if (input && areElementsNear(element, input)) {
      score += 5;
      const elementRect = element.getBoundingClientRect();
      const inputRect = input.getBoundingClientRect();
      const elementCenterX = (elementRect.left + elementRect.right) / 2;
      const rightSideThreshold = inputRect.left + inputRect.width * 0.72;
      const leftSideThreshold = inputRect.left + inputRect.width * 0.35;

      if (elementCenterX > rightSideThreshold) {
        score += 7;
      } else if (elementCenterX < leftSideThreshold) {
        score -= 5;
      }
    }

    if (
      label.includes("tool")
      || label.includes("tools")
      || label.includes("도구")
      || label.includes("attach")
      || label.includes("upload")
      || label.includes("model")
      || label.includes("모델")
    ) {
      score -= 8;
    }

    return score;
  }

  function areElementsNear(left, right) {
    const leftRect = left.getBoundingClientRect();
    const rightRect = right.getBoundingClientRect();
    const verticalDistance = Math.abs((leftRect.top + leftRect.bottom) / 2 - (rightRect.top + rightRect.bottom) / 2);
    const horizontalDistance = Math.abs((leftRect.left + leftRect.right) / 2 - (rightRect.left + rightRect.right) / 2);
    return verticalDistance < 180 && horizontalDistance < 900;
  }

  function clickElementLikeUser(element) {
    clickElementAt(element, 0.5, 0.5);
  }

  function clickElementAt(element, xRatio, yRatio) {
    const rect = element.getBoundingClientRect();
    const clientX = rect.left + rect.width * xRatio;
    const clientY = rect.top + rect.height * yRatio;

    for (const type of ["pointerdown", "mousedown", "pointerup", "mouseup", "click"]) {
      const event = type.startsWith("pointer")
        ? new PointerEvent(type, { bubbles: true, cancelable: true, clientX, clientY, pointerId: 1, pointerType: "mouse" })
        : new MouseEvent(type, { bubbles: true, cancelable: true, clientX, clientY });
      element.dispatchEvent(event);
    }
  }

  function isDisabled(element) {
    return Boolean(
      element.disabled
      || element.getAttribute("aria-disabled") === "true"
      || element.hasAttribute("disabled")
    );
  }

  function isVisible(element) {
    const rect = element.getBoundingClientRect();
    const style = globalThis.getComputedStyle(element);
    return rect.width > 0
      && rect.height > 0
      && style.visibility !== "hidden"
      && style.display !== "none";
  }

  function getElementLabel(element) {
    return [
      element.getAttribute("aria-label") || "",
      element.getAttribute("title") || "",
      element.getAttribute("data-tooltip") || "",
      element.getAttribute("data-testid") || "",
      element.innerText || "",
      element.textContent || ""
    ].join(" ");
  }

  function getNearbyText(element) {
    const parts = [];
    let current = element;

    for (let depth = 0; current && depth < 4; depth += 1) {
      if (current instanceof HTMLElement) {
        parts.push(current.innerText || current.textContent || "");
        parts.push(getElementLabel(current));
      }

      current = current.parentElement;
    }

    return parts.join(" ");
  }

  function normalizeForComparison(value) {
    return String(value || "").replace(/\s+/g, " ").trim().toLowerCase();
  }

  function uniqueElements(elements) {
    return Array.from(new Set(elements.filter(Boolean)));
  }

  function delay(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  main().catch((error) => {
    globalThis.YGS.warn("Gemini content script failed", error);
  });
})();
